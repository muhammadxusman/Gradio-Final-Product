import mysql from 'mysql';
const db = mysql.createConnection({
    host: "rtzsaka6vivj2zp1.cbetxkdyhwsb.us-east-1.rds.amazonaws.com",
    user: "d5ji0rn504phmt5l",
    password: "eeco09aqlnrjzq0b",
    database: "rz8o4nx4iq2bdryg",
})
export default db;
