const BASE_URL = 'https://gradio-67e15e0568fb.herokuapp.com';
export { BASE_URL };
